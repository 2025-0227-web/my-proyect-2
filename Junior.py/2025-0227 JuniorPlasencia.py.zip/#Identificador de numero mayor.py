
# Solicitar tres números al usuario
num1 = float(input("Introduce el primer número: "))
num2 = float(input("Introduce el segundo número: "))
num3 = float(input("Introduce el tercer número: "))

# Determinar cuál es el mayor
mayor = max(num1, num2, num3)

# Mostrar resultado
print(f"El número mayor es: {mayor}")
